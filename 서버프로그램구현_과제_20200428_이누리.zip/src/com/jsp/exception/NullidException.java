package com.jsp.exception;

public class NullidException extends Exception {
	
	public NullidException() {
		super("아이디 입력해줄래요?");
	}

}
