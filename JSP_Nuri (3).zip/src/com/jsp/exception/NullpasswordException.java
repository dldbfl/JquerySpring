package com.jsp.exception;

public class NullpasswordException extends Exception {
	
	public NullpasswordException() {
		super("패스워드 입력해줄래요?");
	}

}
