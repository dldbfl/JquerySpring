package com.jsp.request;

public class DeleteReplyRequest {
	
	private int rno;
	private int bno;
	private int Page;
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getPage() {
		return Page;
	}
	public void setPage(int Page) {
		this.Page = Page;
	}

	
}
