package com.jsp.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.dto.MemberVO;
import com.jsp.request.MemberModifyRequest;
import com.jsp.request.MemberRegistRequest;
import com.jsp.service.MemberServiceImpl;
import com.jsp.utils.ViewResolver;

@WebServlet("/member/modify")
public class MemberModifyServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "member/modify";
		   
		  String   id         = request.getParameter("id");
		  String   pwd        = request.getParameter("pwd"); 
		  String   email      = request.getParameter("email"); 
		  String   picture    = request.getParameter("picture"); 
		  String   phone      = request.getParameter("phone"); 
	      String   authority  = request.getParameter("authority");
	      String   name       = request.getParameter("name");
		
	      MemberModifyRequest memberReq = new MemberModifyRequest(id,pwd,authority,email,phone,picture,name);
	      
	      MemberVO member = memberReq.toMemberVO();
	      
		request.setAttribute("member", member);
		
		ViewResolver.view(request, response, url);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		  String   url        = "redirect:/member/modify";
		   
		  String   id         = request.getParameter("id");
		  String   pwd        = request.getParameter("pwd"); 
		  String   email      = request.getParameter("email"); 
		  String   picture    = request.getParameter("picture"); 
		  String[] phone      = request.getParameterValues("phone"); 
	      String   authority  = request.getParameter("authority");
	      String   name       = request.getParameter("name");
	      
	      MemberRegistRequest memberReq = new MemberRegistRequest(id,pwd,authority,email,phone,picture,name);
	      
	      MemberVO member = memberReq.toMemberVO();
	      
	      	try {
				MemberServiceImpl.getInstance().modify(member);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	      	
	      	HttpSession session = request.getSession();
	      	session.invalidate();
	      	MemberVO loginUser = null;
			try {
				loginUser = MemberServiceImpl.getInstance().getMember(id);
				session.setAttribute("loginUser", loginUser);
				session.setMaxInactiveInterval(60*10); // 세션 유지시간
			} catch (SQLException e) {
				url="error/500_error";
				e.printStackTrace();
				
			}
	      	
	      	ViewResolver.view(request, response, url);
	      
	      
	      
	}

}
